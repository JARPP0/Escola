// Mini-GD

/*
  - circuito base{
      - sistema de pulo
      - sistema de fases
      - sistema de morte
    }
  - sprites
*/

/*
    O tema é uma recriação do jogo chamado Geometry Dash (abreviado para GD)

    1. Um jogo do tipo runner, como o jogo do dinossauro, com sistema de fases
    onde o jogador deve sobreviver até o final sem morrer.

    2. Variedade de obstáculos e mecânicas para o jogador aprender o jogo aos
    poucos

    3. Sistema para criaçâo de fases, para a conta jogar usando as mecânicas do jogo
*/
console.log(transferList.password)