<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "database";

    $conn = new mysqli($host, $user, $pass, $db);
?>